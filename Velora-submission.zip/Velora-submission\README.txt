TEAM: VELORA

CPRI Hackathon Final Submission

Contents:
- Velora.csv - Final prediction file
- Summary.pdf - Project summary
- Methodology.pdf - Technical methodology
- source_code - Source code, requirements and tests

Reproducibility:
Random seed: 42
Python: 3.14.4

Final CSV:
350 rows
3 columns
0 null values
0 duplicate Test_ID values

Final verification:
CP12.1 PASS
Official CPRI dataset verified
Production frozen
Submission verified
